<?php
    echo "<script>
        window.open('../popup.php','pop','width=600,height=200,top=100,left=100');
    </script>";
?>